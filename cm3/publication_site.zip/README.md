# Recharge France

Comparer un département au repère métropolitain pour préparer une étude de déploiement de bornes. Prototype pédagogique, sources publiques IRVE et SDES créditées dans l’interface. Données datées ; aucune disponibilité en temps réel ni conclusion de rentabilité.

Publier ces fichiers à la racine de GitHub Pages après autorisation. Aucun suivi individuel ni outil de mesure des visites installé.
