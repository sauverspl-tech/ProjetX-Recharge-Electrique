# Recharge France

Comparateur départemental CM3. Données publiques sous Licence Ouverte 2.0 ; sources et dates dans le prototype.
Analyse et retours : https://github.com/sauverspl-tech/ProjetX-Recharge-Electrique
